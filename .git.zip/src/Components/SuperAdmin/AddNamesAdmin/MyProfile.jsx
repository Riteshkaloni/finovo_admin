import React, { useState, useEffect } from "react";
import { BaseUrl } from "../../baseUrl";
import { FiEdit } from "react-icons/fi";
import { useNavigate } from "react-router-dom";

const MyProfile = () => {
  const [firstName, setFirstName] = useState("");
  const [middleName, setMiddleName] = useState("");
  const [lastName, setLastName] = useState("");
  const [isProfileUpdated, setIsProfileUpdated] = useState(false);
  const [profileImage, setProfileImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const navigate = useNavigate();

  useEffect(() => {
    fetchUserData();
  }, []);

  // Fetch existing user data
  const fetchUserData = async () => {
    const adminAuth = localStorage.getItem("adminAuth");

    if (!adminAuth) {
      setError("Authorization token is missing. Please log in.");
      return;
    }

    const apiUrl = `${BaseUrl}/admin/getAdminProfile`;
    try {
      const response = await fetch(apiUrl, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${adminAuth}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        const { firstName, middleName, lastName, profileImage } = data.admin;
        setFirstName(firstName);
        setMiddleName(middleName || "");
        setLastName(lastName);
        setProfileImage(profileImage);
      } else {
        setError("Failed to fetch profile details.");
      }
    } catch (error) {
      setError("An error occurred while fetching profile details.");
    }
  };

  // Handle image change
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfileImage(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  // Handle form submission to update profile details including image
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccessMessage("");

    const adminAuth = localStorage.getItem("adminAuth");

    if (!adminAuth) {
      setError("Authorization token is missing. Please log in.");
      return;
    }

    const apiUrl = `${BaseUrl}/admin/uploadProfilePictureAdmin`;
    const formData = new FormData();

    formData.append("firstName", firstName);
    formData.append("middleName", middleName || "");
    formData.append("lastName", lastName);
    formData.append("isProfileUpdated", isProfileUpdated);
    if (profileImage) {
      formData.append("image", profileImage);
    }

    try {
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${adminAuth}`,
        },
        body: formData,
      });

      if (response.ok) {
        const data = await response.json();
        setSuccessMessage("Profile updated successfully!");
        setProfileImage(data.admin.profileImage); // Update the image with the server response
      } else {
        const errorData = await response.json();
        setError(errorData.message || "Failed to update profile.");
      }
    } catch (error) {
      setError("An error occurred while updating the profile.");
    }
  };

  // Trigger file input click when image is clicked
  const handleImageClick = () => {
    document.getElementById("profileImageInput").click();
  };

  const handleNavigate = () => {
    navigate("/UpdateAdminName");
  };

  return (
    <div className="p-4">
      <h2 className="text-lg font-semibold">Super Admin Profile</h2>
      <div className="flex justify-end">
        <FiEdit onClick={handleNavigate} className="cursor-pointer" />
      </div>
      {error && <p className="text-red-600">{error}</p>}
      {successMessage && <p className="text-green-600">{successMessage}</p>}

      <div className="flex items-center space-x-4">
        {/* Profile Image */}
        <div className="relative">
          <img
            src={imagePreview || profileImage || "/path/to/default-avatar.jpg"}
            alt="Profile"
            className="w-24 h-24 rounded-full object-cover cursor-pointer"
            onClick={handleImageClick}
          />
          <input
            type="file"
            id="profileImageInput"
            style={{ display: "none" }}
            accept="image/*"
            onChange={handleImageChange}
          />
        </div>
        <div>
          <h3 className="text-xl">{`${firstName} ${middleName} ${lastName}`}</h3>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4 mt-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">
            First Name
          </label>
          <input
            type="text"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm"
            placeholder="Enter First Name"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Middle Name
          </label>
          <input
            type="text"
            value={middleName}
            onChange={(e) => setMiddleName(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm"
            placeholder="Enter Middle Name"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Last Name
          </label>
          <input
            type="text"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm"
            placeholder="Enter Last Name"
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md"
        >
          Update Profile
        </button>
      </form>
    </div>
  );
};

export default MyProfile;
