import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { BaseUrl } from '../../../baseUrl';
import Navbar from '../../../Navbar/Navbar';
import Header from '../../../Header/Header';

const AllFeatures = () => {
  const [features, setFeatures] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const API_URL = `${BaseUrl}/admin/getAllFeatures`;
  const adminAuth = localStorage.getItem('adminAuth')


  useEffect(() => {
    const fetchFeatures = async () => {
      try {
        setLoading(true);
        const response = await axios.get(API_URL, {
          headers: {
            Authorization: `Bearer ${adminAuth}`,
          },
        });


        const featuresData = response.data?.features || [];


        const filteredFeatures = featuresData.map((feature) => feature.featureName);

        setFeatures(filteredFeatures);
      } catch (err) {
        setError("Failed to fetch features.");
      } finally {
        setLoading(false);
      }
    };

    fetchFeatures();
  }, [adminAuth]);
  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  return (
    <>
    <div className="flex ">
      {/* Navbar */}
      <Navbar />

      <div className="flex-1 w-[78vw]">
        {/* Header positioned next to Navbar */}
        <div className="flex items-center p-4 bg-gray-100">
          <Header />
        </div>

        {/* Features List */}
        <div className="p-4">
          <h2 className="text-lg font-bold mb-4">Features List</h2>
          <ul className="list-disc pl-5">
            {features.length > 0 ? (
              features.map((feature, index) => (
                <li key={index} className="py-1">
                  {feature}
                </li>
              ))
            ) : (
              <li>No features found</li>
            )}
          </ul>
        </div>
      </div>
    </div>
    </>
  );
};

export default AllFeatures;
