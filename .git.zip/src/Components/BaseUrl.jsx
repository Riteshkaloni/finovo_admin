export const BaseUrl='http://192.168.1.20:9000';

// Set Token Function
// const setToken = (token) => {
//     if (token) {
//       // Store token in localStorage
//       localStorage.setItem('authToken', token);
//     } else {
//       console.error("No token provided");
//     }
//   };

//   // Example usage of setToken
//   // This would typically be called after a successful login
//   setToken('authToken   ');
