import React from "react";

import Header from "../../Components/Header/Header";

const Home = () => {
  return (
    <>
      <div className="  h-[100vh] bg-slate-200 ">
        <div className="flex    ">
          {/* Part 1 */}
          <div>
            <Header />

            <div className=" flex justify-center mt-40 ">
              <div className=" bg-white h-full w-[94%] p-4 rounded-lg shadow-xl">
                <div className=" flex gap-4  ">
                  <div>
                    <img src="" alt="country" />
                  </div>
                  <div className="flex justify-between gap-10">
                    <div>
                      <h4>country</h4>
                      <p>United State</p>
                    </div>
                    <div>
                      <h4>slaes</h4>
                      <p>2500</p>
                    </div>
                    <div>
                      values
                      <p>$76546</p>
                    </div>
                    <div>
                      <h4>Bounce</h4>
                      <p>20.9%</p>
                    </div>
                  </div>
                </div>
                <div className=" flex    gap-4">
                  <div>
                    <img src="" alt="country" />
                  </div>
                  <div className="flex justify-between gap-10">
                    <div>
                      <h4>country</h4>
                      <p>United State</p>
                    </div>
                    <div>
                      <h4>slaes</h4>
                      <p>2500</p>
                    </div>
                    <div>
                      values
                      <p>$76546</p>
                    </div>
                    <div>
                      <h4>Bounce</h4>
                      <p>20.9%</p>
                    </div>
                  </div>
                </div>
                <div className=" flex    gap-4">
                  <div>
                    <img src="" alt="country" />
                  </div>
                  <div className="flex justify-between gap-10">
                    <div>
                      <h4>country</h4>
                      <p>United State</p>
                    </div>
                    <div>
                      <h4>slaes</h4>
                      <p>2500</p>
                    </div>
                    <div>
                      values
                      <p>$76546</p>
                    </div>
                    <div>
                      <h4>Bounce</h4>
                      <p>20.9%</p>
                    </div>
                  </div>
                </div>
                <div className=" flex     gap-4">
                  <div>
                    <img src="" alt="country" />
                  </div>
                  <div className="flex justify-between gap-10">
                    <div>
                      <h4>country</h4>
                      <p>United State</p>
                    </div>
                    <div>
                      <h4>slaes</h4>
                      <p>2500</p>
                    </div>
                    <div>
                      values
                      <p>$76546</p>
                    </div>
                    <div>
                      <h4>Bounce</h4>
                      <p>20.9%</p>
                    </div>
                  </div>
                </div>
                <div className=" flex    gap-4">
                  <div>
                    <img src="" alt="country" />
                  </div>
                  <div className="flex justify-between gap-10">
                    <div>
                      <h4>country</h4>
                      <p>United State</p>
                    </div>
                    <div>
                      <h4>slaes</h4>
                      <p>2500</p>
                    </div>
                    <div>
                      values
                      <p>$76546</p>
                    </div>
                    <div>
                      <h4>Bounce</h4>
                      <p>20.9%</p>
                    </div>
                  </div>
                </div>
                <div className=" flex    gap-4">
                  <div>
                    <img src="" alt="country" />
                  </div>
                  <div className="flex justify-between gap-10">
                    <div>
                      <h4>country</h4>
                      <p>United State</p>
                    </div>
                    <div>
                      <h4>slaes</h4>
                      <p>2500</p>
                    </div>
                    <div>
                      values
                      <p>$76546</p>
                    </div>
                    <div>
                      <h4>Bounce</h4>
                      <p>20.9%</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Part 2 */}
          {/* <div className=" bg-slate-500 w-64 h-80 mt-40 ">
            <img src="" alt="World" />
          </div> */}
        </div>
      </div>
    </>
  );
};

export default Home;
